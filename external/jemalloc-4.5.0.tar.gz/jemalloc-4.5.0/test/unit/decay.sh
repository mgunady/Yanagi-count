#!/bin/sh

export MALLOC_CONF="purge:decay,decay_time:1"
